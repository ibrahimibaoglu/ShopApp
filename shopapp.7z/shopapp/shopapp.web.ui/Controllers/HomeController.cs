using Microsoft.AspNetCore.Mvc;

namespace shopapp.web.ui.Controllers
{
    public class HomeController:Controller
    {

    }




}